#!/usr/bin/python
from brain_games.game_logic import guess_even


def main():
    print('Welcome to the Brain Games!')
    guess_even()


if __name__ == '__main__':
    main()
